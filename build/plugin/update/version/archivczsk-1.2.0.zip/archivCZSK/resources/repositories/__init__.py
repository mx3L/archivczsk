from modules import xbmc_doplnky, dmd_czech
repo_modules = xbmc_doplnky + dmd_czech