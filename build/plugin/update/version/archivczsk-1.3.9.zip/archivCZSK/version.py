from . import _

title = _("ArchivCZSK")
version = "1.3.9"
author = "mx3L,misanov"
description = _("Playing CZ/SK archives")
url = "https://github.com/archivczsk/archivczsk/"
email = "archivczsk@seznam.cz"
