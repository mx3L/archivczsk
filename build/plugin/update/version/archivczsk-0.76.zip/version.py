from . import _

title = _("ArchivCZSK")
version = "0.7"
author = "mx3L"
description = _("Playing CZ/SK archives")
url = "https://code.google.com/p/archivy-czsk/"
email = "mxfitsat@gmail.com"
