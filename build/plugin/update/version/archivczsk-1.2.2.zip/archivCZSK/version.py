from . import _

title = _("ArchivCZSK")
version = "1.2.2"
author = "mx3L,chaoss"
description = _("Playing CZ/SK archives")
url = "https://github.com/mx3L/archivczsk/"
email = "mxfitsat@gmail.com"
