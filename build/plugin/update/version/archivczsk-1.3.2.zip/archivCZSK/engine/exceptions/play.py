class PlayException(Exception):
    pass
        
class UrlNotExistError(PlayException):
    pass
