'''
Contains module names of repositories, it's used to prevent module
name collisions in sys.modules
'''

xbmc_doplnky = [
                'resolver',
                'search',
                'StorageServer',
                'storageserverdummy',
                'util',
                'xbmcutil',
                'xbmcprovider',
                'provider']

dmd_czech = [
                'servertools',
                'parseutils',
                'servertools',
                'vk',
                'videomail',
                'videobb',
                'videomail',
                'videonet',
                'videoweed',
                'videozer',
                'youtube',
                'ytube']